<?php
return [
    'name' => 'Community Learning Day',
    'headline' => 'Choose a workshop for the event',
    'intro' => 'Explore event sessions and submit a sample ticket request.',
    'quantityLabel' => 'Tickets requested',
    'min' => 1,
    'max' => 6,
    'notice' => 'No payment, seat allocation or email ticket is issued.',
    'items' => [
        [1, 'Creative workshop', 2000],
        [2, 'Business talk', 1500],
        [3, 'Digital skills session', 2500],
    ]
];
