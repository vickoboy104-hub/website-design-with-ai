PHP practical 4: A validated estimate form

Process a real form on the server without storing customer data.

HOW TO RUN
Open this folder in VS Code. Choose Terminal → New Terminal. Run php -S 127.0.0.1:8000. Keep it running, then open http://127.0.0.1:8000/index.php. Stop the earlier server with Ctrl + C before starting another.

EXPECTED RESULT
Cupcake box estimate
Boxes [2]  [Calculate on server]
Server estimate: NGN 6000
Invalid POST: Please enter a valid whole quantity.

WHAT THE CODE DOES
$_SERVER and REQUEST_METHOD: Detect whether the request is a form POST.
$_POST and ??: Read the submitted quantity or an empty default.
is_string and ? :: Reject unexpected array-shaped input before validating the scalar value.
filter_var and FILTER_VALIDATE_INT: Validate a whole number within min_range and max_range.
if, === false and else: Distinguish validation failure from valid numeric values.
dot, * and htmlspecialchars: Join the fixed message to a server calculation and escape output.
form method, action and name: POST to this PHP file and identify the submitted field.
label, id, number type, min, max and required: Provide associated labels and browser checks; PHP checks again.
button, h1, p and document shell: Submit, name the page and show the resulting message.

TRY IT
Change the PHP unit price to 3500 and test two boxes. Do not add a client-controlled price.

CHECK
2 produces 6000.
A direct invalid POST is rejected by PHP.