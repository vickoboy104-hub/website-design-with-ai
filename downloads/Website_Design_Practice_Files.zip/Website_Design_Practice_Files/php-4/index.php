<?php
$message = 'Enter a quantity from 1 to 100.';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $raw = $_POST['quantity'] ?? '';
    $quantity = is_string($raw) ? filter_var($raw,
        FILTER_VALIDATE_INT, ['options' => [
            'min_range' => 1, 'max_range' => 100]]) : false;
    if ($quantity === false) {
        $message = 'Please enter a valid whole quantity.';
    } else {
        $message = 'Server estimate: NGN ' . $quantity * 3000;
    }
}
?>
<!doctype html>
<html lang="en">
<head><meta charset="UTF-8"><title>Bakery estimate</title></head>
<body>
<h1>Cupcake box estimate</h1>
<form method="post" action="index.php">
  <label for="qty">Boxes</label>
  <input id="qty" name="quantity" type="number" min="1" max="100" required>
  <button>Calculate on server</button>
</form>
<p><?= htmlspecialchars($message, ENT_QUOTES, 'UTF-8') ?></p>
</body>
</html>