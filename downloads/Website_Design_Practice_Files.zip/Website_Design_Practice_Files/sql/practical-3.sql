UPDATE products
SET price = 4500
WHERE id = 3;
INSERT INTO products (id, name, category, price)
VALUES (4, 'Practice only', 'Test', 0);
DELETE FROM products WHERE id = 4;
SELECT id, name, price FROM products ORDER BY id;
