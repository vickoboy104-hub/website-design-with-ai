PRAGMA foreign_keys = ON;
CREATE TABLE products (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  category TEXT NOT NULL,
  price INTEGER NOT NULL CHECK (price >= 0)
);
INSERT INTO products (id, name, category, price) VALUES
  (1, 'Polo shirt', 'Clothing', 7500),
  (2, 'Canvas bag', 'Bags', 6000),
  (3, 'Cap', 'Clothing', 4000);
SELECT id, name, category, price FROM products;
