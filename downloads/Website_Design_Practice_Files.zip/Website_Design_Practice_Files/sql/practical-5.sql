SELECT c.name, SUM(o.quantity * p.price) AS total
FROM orders AS o
JOIN customers AS c ON c.id = o.customer_id
JOIN products AS p ON p.id = o.product_id
GROUP BY c.id, c.name
ORDER BY total DESC;
BEGIN TRANSACTION;
UPDATE products SET price = 1 WHERE id = 2;
ROLLBACK;
SELECT name, price FROM products WHERE id = 2;
