SELECT name, price
FROM products
WHERE price >= 6000
ORDER BY price DESC;
SELECT name
FROM products
WHERE name LIKE '%bag%';
