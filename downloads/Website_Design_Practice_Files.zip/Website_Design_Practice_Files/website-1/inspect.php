<?php
require __DIR__ . '/app.php';
$rows = $db->query('SELECT id, customer, quantity, unit_price, total
                   FROM requests ORDER BY id')->fetchAll(PDO::FETCH_ASSOC);
foreach ($rows as $row) echo implode(' | ', $row) . PHP_EOL;
