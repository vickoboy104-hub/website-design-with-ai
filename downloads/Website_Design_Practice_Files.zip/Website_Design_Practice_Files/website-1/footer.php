</main>
<footer><p>Fictional classroom website. Requests are not confirmed orders.</p></footer>
<script src="app.js" defer></script>
</body>
</html>
