<?php
return [
    'name' => 'Ada Bakes',
    'headline' => 'Cakes for your next celebration',
    'intro' => 'Explore our fictional bakery catalogue and practise making an enquiry.',
    'quantityLabel' => 'Number of boxes',
    'min' => 1,
    'max' => 100,
    'notice' => 'Sample bakery enquiry. No payment or delivery is arranged.',
    'items' => [
        [1, 'Vanilla box', 3000],
        [2, 'Chocolate box', 3500],
        [3, 'Fruit box', 4000],
    ]
];
