<?php
$config = require __DIR__ . '/config.php';
if (!is_dir(__DIR__ . '/data')) mkdir(__DIR__ . '/data');
$db = new PDO('sqlite:' . __DIR__ . '/data/site.sqlite');
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$db->exec('PRAGMA foreign_keys = ON');
$db->exec(file_get_contents(__DIR__ . '/schema.sql'));
$insert = $db->prepare(
    'INSERT OR IGNORE INTO items (id, name, price) VALUES (?, ?, ?)'
);
foreach ($config['items'] as $item) $insert->execute($item);
echo "Setup complete. Start the local server.\n";
