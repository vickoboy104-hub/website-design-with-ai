<!doctype html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport"
        content="width=device-width, initial-scale=1">
  <title><?= e($config['name']) ?></title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
<header>
  <p class="brand"><?= e($config['name']) ?></p>
  <nav aria-label="Main navigation">
    <a href="index.php">Home</a>
    <a href="catalog.php">Catalogue</a>
    <a href="request.php">Make a request</a>
  </nav>
</header>
<main>
