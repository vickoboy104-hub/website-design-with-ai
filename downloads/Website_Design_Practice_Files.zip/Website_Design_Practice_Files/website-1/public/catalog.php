<?php
require __DIR__ . '/../app.php';
$items = $db->query('SELECT * FROM items ORDER BY id')->fetchAll(PDO::FETCH_ASSOC);
require __DIR__ . '/../header.php';
?>
<h1>Choose an option</h1>
<label for="search">Search the catalogue</label>
<input id="search" type="search">
<p id="empty" hidden>No matching option.</p>
<div class="cards">
<?php foreach ($items as $item): ?>
  <article data-name="<?= e(strtolower($item['name'])) ?>">
    <h2><?= e($item['name']) ?></h2>
    <p>Sample unit price: NGN <?= (int) $item['price'] ?></p>
    <a href="request.php?item=<?= (int) $item['id'] ?>">Request this</a>
  </article>
<?php endforeach; ?>
</div>
<?php require __DIR__ . '/../footer.php'; ?>
