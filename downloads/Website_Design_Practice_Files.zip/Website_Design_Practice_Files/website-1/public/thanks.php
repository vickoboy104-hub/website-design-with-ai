<?php
require __DIR__ . '/../app.php';
$receipt = $_SESSION['receipt'] ?? null;
require __DIR__ . '/../header.php';
?>
<h1>Request result</h1>
<?php if ($receipt): ?>
  <p>Saved request <?= (int) $receipt['id'] ?></p>
  <p>Thank you, <?= e($receipt['name']) ?>.</p>
  <p>Recorded estimate: NGN <?= (int) $receipt['total'] ?></p>
  <p>This is a request, not a confirmed booking or payment.</p>
<?php else: ?>
  <p>No request has been submitted in this session.</p>
<?php endif; ?>
<?php require __DIR__ . '/../footer.php'; ?>
