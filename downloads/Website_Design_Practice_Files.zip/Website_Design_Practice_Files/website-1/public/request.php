<?php
require __DIR__ . '/../app.php';
$items = $db->query('SELECT * FROM items ORDER BY id')->fetchAll(PDO::FETCH_ASSOC);
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_POST['token'] ?? '';
    if (!is_string($token) || !hash_equals($_SESSION['token'], $token)) {
        http_response_code(403);
        exit('Form expired. Return to the request page.');
    }
    $name = $_POST['customer'] ?? '';
    $itemId = $_POST['item'] ?? '';
    $raw = $_POST['quantity'] ?? '';
    if (!is_string($name) || !is_string($itemId) || !is_string($raw)) {
        http_response_code(400);
        exit('Invalid input.');
    }
    $name = trim($name);
    $qty = filter_var($raw, FILTER_VALIDATE_INT, ['options' => [
        'min_range' => $config['min'], 'max_range' => $config['max']]]);
    $find = $db->prepare('SELECT * FROM items WHERE id = ?');
    $find->execute([$itemId]);
    $item = $find->fetch(PDO::FETCH_ASSOC);
    if ($name === '' || strlen($name) > 60 || $qty === false || !$item) {
        $error = 'Check your name, option and quantity range.';
    } else {
        $total = $qty * (int) $item['price'];
        $save = $db->prepare('INSERT INTO requests
          (customer, item_id, quantity, unit_price, total)
          VALUES (?, ?, ?, ?, ?)');
        $save->execute([$name, $item['id'], $qty, $item['price'], $total]);
        $_SESSION['receipt'] = ['name' => $name, 'total' => $total,
            'id' => $db->lastInsertId()];
        $_SESSION['token'] = bin2hex(random_bytes(32));
        header('Location: thanks.php', true, 303);
        exit;
    }
}
$selected = filter_input(INPUT_GET, 'item', FILTER_VALIDATE_INT);
require __DIR__ . '/../header.php';
?>
<h1>Make a practice request</h1>
<p><?= e($config['notice']) ?></p>
<p role="alert"><?= e($error) ?></p>
<form method="post" action="request.php">
  <input type="hidden" name="token" value="<?= e($_SESSION['token']) ?>">
  <label for="customer">First name</label>
  <input id="customer" name="customer" maxlength="60" required>
  <label for="item">Choose an option</label>
  <select id="item" name="item">
  <?php foreach ($items as $row): ?>
    <option value="<?= (int) $row['id'] ?>"
      <?= $selected === (int) $row['id'] ? 'selected' : '' ?>>
      <?= e($row['name']) ?>
    </option>
  <?php endforeach; ?>
  </select>
  <label for="quantity"><?= e($config['quantityLabel']) ?></label>
  <input id="quantity" name="quantity" type="number" step="1"
    min="<?= $config['min'] ?>" max="<?= $config['max'] ?>" required>
  <button type="submit">Save practice request</button>
</form>
<?php require __DIR__ . '/../footer.php'; ?>
