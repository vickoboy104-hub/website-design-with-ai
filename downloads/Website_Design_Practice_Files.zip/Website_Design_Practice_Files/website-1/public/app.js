const search = document.querySelector('#search');
if (search) {
  const cards = document.querySelectorAll('[data-name]');
  const empty = document.querySelector('#empty');
  search.addEventListener('input', function () {
    const query = search.value.trim().toLowerCase();
    let visible = 0;
    for (const card of cards) {
      const match = card.dataset.name.includes(query);
      card.hidden = !match;
      if (match) visible += 1;
    }
    empty.hidden = visible !== 0;
  });
}
