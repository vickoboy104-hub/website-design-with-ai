<?php
require __DIR__ . '/../app.php';
require __DIR__ . '/../header.php';
?>
<h1><?= e($config['headline']) ?></h1>
<p><?= e($config['intro']) ?></p>
<p><a class="button" href="catalog.php">Explore our options</a></p>
<section>
  <h2>How it works</h2>
  <ol>
    <li>Choose an option from our catalogue.</li>
    <li>Send a fictional practice request.</li>
    <li>Review the saved request confirmation.</li>
  </ol>
</section>
<?php require __DIR__ . '/../footer.php'; ?>
