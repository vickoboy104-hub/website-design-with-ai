<?php
session_start();
$config = require __DIR__ . '/config.php';
function e(string $text): string {
    return htmlspecialchars($text, ENT_QUOTES, 'UTF-8');
}
if (!is_file(__DIR__ . '/data/site.sqlite')) {
    exit('Run php setup.php from the project folder first.');
}
$db = new PDO('sqlite:' . __DIR__ . '/data/site.sqlite');
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$db->exec('PRAGMA foreign_keys = ON');
if (!isset($_SESSION['token'])) {
    $_SESSION['token'] = bin2hex(random_bytes(32));
}
