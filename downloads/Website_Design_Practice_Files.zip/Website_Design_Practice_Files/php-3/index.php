<?php
$services = [
    ['name' => 'Haircut', 'price' => 3000],
    ['name' => 'Hair wash', 'price' => 2000],
    ['name' => 'Beard trim', 'price' => 1500]
];
function e(string $text): string {
    return htmlspecialchars($text, ENT_QUOTES, 'UTF-8');
}
?>
<!doctype html>
<html lang="en">
<head><meta charset="UTF-8"><title>Service prices</title></head>
<body>
<h1>Practice salon prices</h1>
<ul>
<?php foreach ($services as $service): ?>
  <li><?= e($service['name']) ?>: NGN <?= $service['price'] ?></li>
<?php endforeach; ?>
</ul>
</body>
</html>