PHP practical 3: A dynamic price list page

Use an array and loop to generate repeated HTML.

HOW TO RUN
Open this folder in VS Code. Choose Terminal → New Terminal. Run php -S 127.0.0.1:8000. Keep it running, then open http://127.0.0.1:8000/index.php. Stop the earlier server with Ctrl + C before starting another.

EXPECTED RESULT
Practice salon prices
• Haircut: NGN 3000
• Hair wash: NGN 2000
• Beard trim: NGN 1500

WHAT THE CODE DOES
[ ], commas and =>: Build an array of associative arrays; each key maps to a value.
foreach...as, colon and endforeach: Repeat a template once per service; this is PHP alternative control syntax.
$service['name'] and ['price']: Read the current row values by key.
e(), htmlspecialchars and <?= ?>: Escape name text and output the template values; prices are controlled integers here.
HTML doctype, head, meta, title and body: Provide the basic page document.
h1, ul and li: Name the page and display each service in the generated list.

TRY IT
Add a fourth service. Do not copy another li; let the loop do the work.

CHECK
Three list items render.
The added service appears after refreshing.