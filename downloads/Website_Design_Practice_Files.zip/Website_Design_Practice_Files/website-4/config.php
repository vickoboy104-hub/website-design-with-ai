<?php
return [
    'name' => 'Palm Rest Guesthouse',
    'headline' => 'Plan a comfortable short stay',
    'intro' => 'Compare sample nightly room rates and request a stay estimate.',
    'quantityLabel' => 'Number of nights',
    'min' => 1,
    'max' => 14,
    'notice' => 'Dates and availability are not checked. This is a quote request only.',
    'items' => [
        [1, 'Standard room', 25000],
        [2, 'Family room', 40000],
        [3, 'Garden room', 30000],
    ]
];
