Thread Studio - fictional local teaching website
Requirements: supported PHP with PDO and pdo_sqlite.
In this folder: php setup.php
Then: php -S 127.0.0.1:8000 -t public
Open http://127.0.0.1:8000/index.php
Inspect stored test requests in another terminal: php inspect.php
Stop the server before starting another website on the same port.
Never serve the project root. Serve only public.
No payments, emails, authentication or confirmed bookings.
Before real deployment: experienced review, HTTPS, rate limiting,
secure sessions, environment configuration, backups and data policy.
Use fictional names only. Database data/site.sqlite is private.
setup.php seeds items once. Editing config prices later does not update
existing rows. Use a NEW project/database for a clean config exercise.

YOUR FIRST TEST
Choose Polo branding, enter Bola and quantity 10. Expect NGN 25000. Run php inspect.php in another terminal to see the saved row.

YOUR CHANGE TASK
Set a new minimum of 20 in config.php. Confirm both the HTML field and server reject 10. Do not change only the browser field.
