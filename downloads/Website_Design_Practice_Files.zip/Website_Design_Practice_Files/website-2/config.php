<?php
return [
    'name' => 'Thread Studio',
    'headline' => 'Branded clothing for your team',
    'intro' => 'Compare sample garment services and submit a bulk enquiry.',
    'quantityLabel' => 'Number of garments',
    'min' => 10,
    'max' => 500,
    'notice' => 'Minimum 10 garments. This is an enquiry, not an accepted order.',
    'items' => [
        [1, 'Polo branding', 2500],
        [2, 'Apron branding', 1800],
        [3, 'Cap embroidery', 1500],
    ]
];
