<?php
return [
    'name' => 'SkillStart Academy',
    'headline' => 'Practical weekend learning',
    'intro' => 'Browse sample workshops and request one learner place.',
    'quantityLabel' => 'Learner places',
    'min' => 1,
    'max' => 1,
    'notice' => 'One place per request. The request does not confirm admission.',
    'items' => [
        [1, 'Baking basics', 15000],
        [2, 'Bag sewing', 12000],
        [3, 'Web design basics', 18000],
    ]
];
