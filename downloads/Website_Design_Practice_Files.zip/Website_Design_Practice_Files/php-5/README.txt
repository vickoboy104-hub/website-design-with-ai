PHP practical 5: A session based visit counter page

Learn how a server remembers state across requests.

HOW TO RUN
Open this folder in VS Code. Choose Terminal → New Terminal. Run php -S 127.0.0.1:8000. Keep it running, then open http://127.0.0.1:8000/index.php. Stop the earlier server with Ctrl + C before starting another.

EXPECTED RESULT
Welcome back to our reading club
Visits in this session: 1
Refresh: 2, then 3
Separate private window: usually starts at 1

WHAT THE CODE DOES
session_start(): Start or resume a session before any HTML output.
$_SESSION and visits key: Keep a server-side value associated with this session.
?? 0, + 1 and assignment: Use zero on the first visit, increment and save.
$visits and <?= ?>: Read and display the controlled integer counter.
Cookie relationship: A browser cookie usually carries an identifier, while this value is stored server-side.
HTML document shell, h1 and p: Provide a valid page with a heading and two paragraphs.

TRY IT
Refresh three times. Compare a normal window and a private window, then explain why this is not authentication.

CHECK
Counter increases in one session.
PHP starts the session before HTML output.