<?php
session_start();
$_SESSION['visits'] = ($_SESSION['visits'] ?? 0) + 1;
$visits = $_SESSION['visits'];
?>
<!doctype html>
<html lang="en">
<head><meta charset="UTF-8"><title>Session practice</title></head>
<body>
<h1>Welcome back to our reading club</h1>
<p>Visits in this session: <?= $visits ?></p>
<p>This is a counter, not a sign-in system.</p>
</body>
</html>