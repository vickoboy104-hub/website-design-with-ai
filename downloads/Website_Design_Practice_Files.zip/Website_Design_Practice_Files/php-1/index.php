<?php
$name = 'Ada';
function e(string $text): string {
    return htmlspecialchars($text, ENT_QUOTES, 'UTF-8');
}
?>
<!doctype html>
<html lang="en">
<head><meta charset="UTF-8"><title>Welcome</title></head>
<body>
  <h1>Welcome, <?= e($name) ?></h1>
  <p>This greeting was prepared by PHP.</p>
</body>
</html>