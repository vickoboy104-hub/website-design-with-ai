PHP practical 1: A server generated welcome page

Use variables and safe output inside an HTML document.

HOW TO RUN
Open this folder in VS Code. Choose Terminal → New Terminal. Run php -S 127.0.0.1:8000. Keep it running, then open http://127.0.0.1:8000/index.php. Stop the earlier server with Ctrl + C before starting another.

EXPECTED RESULT
Welcome, Ada
This greeting was prepared by PHP.
View source: the greeting text appears
The PHP function itself is not sent to the browser

WHAT THE CODE DOES
<?php, ?> and <?= ?>: Enter PHP, return to HTML and echo an expression in the short output form.
$name, =, quotes and semicolon: Name a text value, assign it and finish the statement.
function e, string and return: Define a reusable text-escaping function with string input and output.
htmlspecialchars, ENT_QUOTES and UTF-8: Escape special characters and both quote types for HTML text with this encoding.
HTML doctype, html, head, meta and title: Declare HTML, language, character encoding and browser-tab title.
body, h1 and p: Show the greeting and explanation in the page body.

TRY IT
Change $name to your first name. Then try <b>Ada</b> and check it appears as literal text.

CHECK
The server URL shows the heading.
View Source does not contain the PHP assignment.