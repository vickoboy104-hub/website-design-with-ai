# Paul’s AI and GitHub workflow

Paul Victor · Beloved Technology

## Paul’s workflow: from an idea to a live website

You do not have to type every line yourself. Your job is to explain the idea, inspect what AI makes and try the website yourself.

Paul uses Codex and Kilo inside VS Code, and also works directly in Qoder. Sometimes he asks ChatGPT to turn an idea into clear instructions first. Either route is useful.

Paul describes using GitHub to store the code for BelovedSubP.com, then pulling updates from his server terminal. We will practise that pattern on a small training project. We have not inspected that business website’s private code or server.

Start with the local project. Move to the server lessons after you can explain and test it.

## AI setup 1: open a folder and choose a helper

A project folder is the home for one website. Your AI helper needs to work inside that folder.

In this screenshot, No providers means a model connection still needs to be chosen. Open that control and follow Kilo’s current sign-in/provider instructions before sending your task.

1. In Windows File Explorer, open Documents. Right-click an empty space → New → Folder. Name it beloved-ai-practice.

2. In VS Code choose File → Open Folder. Select beloved-ai-practice and click Select Folder. Trust it only because you created it.

3. Press Ctrl + Shift + X. This opens Extensions. Search for Codex, Kilo Code or Cline. Use the official installation links below to check the publisher before clicking Install.

4. Click the helper’s icon in the side bar. Follow its sign-in or model-provider setup. Return to VS Code when sign-in finishes.

5. Choose one helper for this task. Start a new conversation and ask: “Which folder can you see? Do not change files yet.”

CHECK  The answer should name beloved-ai-practice. If it names another project, stop and open the correct folder.

Codex: official extension setup

Kilo: official setup and documentation

Cline: official installation guide

## AI setup 2: know what each tool is

**ChatGPT** — A place to discuss an idea and prepare instructions. Planning here is optional.

**Codex extension** — Works inside VS Code beside your project files.

**Codex desktop app** — A separate application, rather than a VS Code extension. Open a local project there and review its changes. Official desktop naming and downloads can change.

**Kilo Code** — An AI coding helper with model choices. Select a free model if that is what you intend to use.

**Cline** — Another coding agent. The correct spelling is Cline. Its extension and model-provider billing are separate things.

**Claude Code** — Anthropic’s coding agent. It can work through its VS Code extension; eligible account access is required.

**Qoder** — A coding workspace for building and reviewing projects. Paul often gives it instructions directly.

Gemini Code Assist appears in Paul’s earlier workflow. Google ended its consumer IDE service on 18 June 2026 and directs those users to Antigravity. Do not follow an old free-account sign-in tutorial if it no longer works.

Free does not mean unlimited. Codex access depends on your account. Kilo’s free models and background-model settings affect cost. Qoder uses plan allowances and credits. Check Usage before starting a long project.

Keep one agent in charge of the same files at a time. To change helper, save the files and ask the first helper to write a short progress note.

Official desktop app guide

Claude Code in VS Code

Google’s consumer migration notice

Kilo free-model settings

Qoder plans and credits

## AI practical 1: let ChatGPT prepare your brief

A brief is a short description of what you want to build. Use this route when your idea is clear in your head but hard to explain.

1. Open ChatGPT and start a new conversation. Paste the message below. Replace the business details with your own idea.

```text
Help me plan a website for Beloved Training Centre.
Users should see courses and send an enquiry.
Use Laravel, Blade, CSS and SQLite for local practice.
I am a beginner using Windows and VS Code.
Ask up to five questions if important details are missing.
Then write a prompt for my coding agent.
Include pages, form fields, validation, mobile layout,
local setup, sample data and a clear completion checklist.
Build in small stages. Do not deploy or take payments.
```

### What you are asking for

**Business and users** — Tell AI who the site helps.

**Laravel and SQLite** — Name the tools so AI does not choose a different stack.

**Questions first** — Give missing details before files are created.

**Completion checklist** — Define what must work so you can check the result.

2. Answer the questions. Read the resulting brief. Remove features you do not need.

3. Copy the final prompt. Paste it into Codex, Kilo or Qoder with your practice folder open.

OUTPUT  You should have a written plan with page names and a short build order. This is a target result, not a screenshot of an executed AI project.

TRY IT  Ask for only Home, Courses and Enquiry in the first version. A small working site is easier to understand.

## AI practical 2: build directly with your agent

You may skip ChatGPT and tell the coding agent your idea directly. This is also Paul’s usual approach in Qoder.

1. Open the project folder in VS Code or Qoder. Start a new agent conversation. Paste your approved brief.

```text
Read this project folder first. Tell me what is already here.
Check the installed PHP, Composer and Node versions.
Explain any missing requirement before installing it.
Propose three small milestones.
First create the home page and explain how to run it.
Do not overwrite unrelated files or deploy the project.
After each milestone, list changed files and tests.
Keep secrets out of the code and use .env.example.
```

2. Read the plan. Let the agent create the first milestone. Review requested terminal commands before allowing them.

3. Open the local address it gives you. Try the page. Ask for one correction at a time.

4. Continue with the courses page, then the enquiry form and database. Do not add payments to this beginner project.

### Read the instruction

**Read the folder** — Avoids building in the wrong place or replacing existing work.

**Check requirements** — AI still needs the correct language tools installed.

**Milestones** — Makes each piece small enough to inspect.

**.env.example** — Stores setting names and harmless examples, not real passwords.

OUTPUT  A working local website plus a README explaining how to start it. Ask AI to show which checks actually ran. A message saying “done” is not proof.

CHECK  Open the site on a narrow browser window. Send an empty form: it should show useful errors. Send a fictional valid enquiry: confirm it was saved.

## AI practical 3: correct a result and keep context

You do not need technical language to report a problem. Say what you clicked, what you expected and what happened.

```text
On the Enquiry page, I clicked Send with an empty name.
I expected a message asking for my name.
Instead, it saved an empty enquiry.
Find the cause and fix the server-side validation.
Keep the existing layout. Test empty and valid submissions.
Explain the change in plain English.
```

“Server-side” means PHP checks the form too. A browser check alone can be bypassed.

If you want ChatGPT’s help, copy the agent’s summary and the exact error. Remove passwords, keys and customer details first.

```text
Here is my project goal and the agent’s latest result.
Explain the error simply. Give me one next instruction
to paste into the coding agent.
Do not guess which files exist; ask for missing evidence.
```

When returning tomorrow, ask the agent to read README.md and a short PROGRESS.md before changing anything. PROGRESS.md should list completed work, remaining work and the command used to start the project.

OUTPUT  The reported problem is fixed, the earlier working features still work, and the progress note matches the files.

## AI practical 4: run the correct local server

Local means running on your own computer. A local address does not publish your website to the internet.

In VS Code choose Terminal → New Terminal. Check that the terminal is in your project folder. Commands differ by project; follow its README.

**HTML, CSS and JavaScript** — For a simple page, open index.html in the browser. Use the earlier Live Server lesson when the project needs a local web server.

**Plain PHP** — From the folder containing index.php, run the PHP command below. PHP must already be installed.

**Laravel** — PHP and Composer must be installed. Finish the Laravel setup lesson first, including .env, the application key and the practice database.

**Django** — Activate the project’s virtual environment and install its requirements before using manage.py.

**Flutter web** — Install Flutter and a supported browser first. flutter doctor tells you what is missing.

```text
php -S localhost:8000
```

Plain PHP: open http://localhost:8000. The -S option starts PHP’s development server. Keep its terminal open. Ctrl + C stops it.

```text
php artisan serve
```

Laravel: open the address printed by Artisan. If the page uses Vite, open a second terminal and run the project’s npm run dev command too.

```text
python manage.py runserver
```

Django: run this beside manage.py, in the activated environment. Open the address it prints.

```text
flutter run -d chrome
```

Flutter: run this inside the Flutter project. It launches the web version in Chrome. Flutter uses Dart, not PHP.

CHECK  If a command is not recognised, the tool is missing or not on PATH. Return to that stack’s installation lesson. Do not paste random fix commands from a chat.

## GitHub practical 1: save your first project online

Git records versions on your computer. GitHub stores a copy online. A repository is one project’s version history. A commit is a named checkpoint. Push sends commits to GitHub; pull brings them down.

1. Create your account at github.com. Then download GitHub Desktop from desktop.github.com. Install it and sign in through its browser sign-in screen.

2. In GitHub Desktop choose File → New repository. Name it beloved-ai-practice. Choose a location you can find. Select the Laravel Git ignore template for a Laravel project. Click Create repository.

3. Choose Repository → Show in Explorer. Copy your finished practice project into this new folder. Copy its files, not a second enclosing folder, and do not copy any old .git folder.

4. Open that new repository folder in VS Code. Keep the framework’s original .gitignore rules. Add the examples below if they are missing.

```text
.env
.env.*
!.env.example
node_modules/
vendor/
*.sqlite
*.sqlite3
*.pem
*.key
```

Each line names files Git should leave out. The ! line allows the safe example settings file. Keep real database files, credentials and private keys out. A .gitignore rule does not remove secrets already committed.

5. Return to GitHub Desktop. In Changes, click each file to review it. Confirm that no .env, real database, password or key is listed. Enter “First working training website” in Summary. Click Commit to main.

6. Click Publish repository. Keep “Keep this code private” selected for your first practice project. Click Publish repository again.

7. Choose Repository → View on GitHub. Check that your code appears and private files do not. GitHub is now holding your checkpoint; this alone does not make a PHP website live.

Download GitHub Desktop

GitHub Desktop documentation

## GitHub practical 2: let AI prepare an update

Work in the repository folder you published. First make one small change, such as correcting the course contact text.

```text
Change the contact heading to Ask about a course.
Keep the rest of the page unchanged.
Run the relevant checks and show the diff.
Check that no secrets or local database files are staged.
Prepare a clear commit message. Do not push yet.
```

1. Run the site locally. Check the new heading and try the enquiry form again.

2. In GitHub Desktop, review Changes. Commit the tested files, then click Push origin. On GitHub, refresh the repository and find your new commit.

An agent can also commit and push when you explicitly ask it to, it has Git installed, and your account is signed in. Do not give it your account password in a prompt.

```text
The changes are reviewed and tested.
Confirm the repository URL and current branch.
Commit only this task’s files with a clear message.
Push to origin on this branch. Never force-push.
Report the commit ID and whether the push succeeded.
```

A branch is a separate line of work. For a shared or live project, ask AI to use a feature branch and open a pull request. Review that proposal before merging it into main.

### Useful checks in the terminal

```text
git status
git remote -v
git log -1 --oneline
```

**git status** — Shows changed files and the current branch.

**git remote -v** — Shows which online repository receives a push. Do not share a URL containing a token.

**git log -1 --oneline** — Shows the latest checkpoint ID and its message.

CHECK  The newest commit on GitHub must match the one you intended to publish. Stop if the repository or branch is wrong.

## Server practical 1: prepare a safe deployment

A server is a computer that stays available to visitors. Deploy means putting a tested version there and preparing it to run.

Use a training server or staging site first. These instructions assume a Linux host with SSH access and an existing working Laravel installation. First-time server setup is a separate job; do not assume that cloning code creates a working server.

Before continuing, confirm: compatible PHP and Composer; the needed PHP extensions; a database; a web server; HTTPS; a domain; and a tested database/files backup. The web root must be Laravel’s public folder, not the whole project.

Your host must provide the SSH user, address, port and project directory. Use its documented values. HOST, USER, OWNER and REPO below are placeholders, not literal account names.

```text
ssh USER@HOST
```

ssh opens the server terminal. Check the host fingerprint against your hosting panel on the first connection. Enter your own credentials through the secure prompt, not in AI chat.

For a private repository, use a read-only deploy key tied to that repository. Create a dedicated key on the server; keep the private file there.

```text
ssh-keygen -t ed25519 -f ~/.ssh/course_deploy
cat ~/.ssh/course_deploy.pub
```

ssh-keygen creates the key pair. Choose a new filename; never overwrite an existing key. cat displays only the .pub public key, which is the part you copy to GitHub.

In GitHub open the repository → Settings → Deploy keys → Add deploy key. Give it a name, paste the public key and leave Allow write access unticked. Save it.

Tell your host to configure SSH to use this dedicated key. A public key on GitHub is not enough if SSH is selecting a different private key.

GitHub: deploy-key setup

Laravel: production deployment requirements

## Server practical 2: first copy and production settings

This is a checklist for a configured training host. Have your hosting provider prepare the web-server and database settings first. Use the project’s documented Laravel version requirements.

1. In the server terminal, enter the directory assigned by the host. Clone into a new, empty project location using your configured deploy key.

```text
git clone git@github.com:OWNER/REPO.git training-site
cd training-site
composer install --no-dev --optimize-autoloader
```

git clone downloads the repository. cd enters it. Composer installs the locked PHP dependencies without development-only packages. Stop if any command fails.

2. For this first installation only, copy .env.example to .env. Enter production settings using the host’s secure editor. Set APP_ENV=production, APP_DEBUG=false and APP_URL to the HTTPS address. Use the server database credentials.

```text
cp .env.example .env
php artisan key:generate
```

cp creates the private settings file. key:generate creates the application encryption key. Do this only for a new installation; do not replace the key during ordinary updates.

3. Confirm the correct database. Review the migrations and take a backup before applying them. If this is your empty training database, run the reviewed migrations.

```text
php artisan migrate --force
```

This changes the database schema. --force permits production execution; it does not make the change safe. Never use migrate:fresh on a live database: it deletes tables.

4. If package-lock.json and the project’s build script exist, install the locked front-end dependencies and build the assets. Otherwise follow the project README.

```text
npm ci
npm run build
```

npm ci installs from the lockfile. npm run build creates production CSS/JavaScript assets. Node must be available on this build machine. A production server may instead receive assets built in CI.

5. Configure storage permissions through the host. If the project uses public file uploads, follow its storage-link instructions. Point the site to public/, enable HTTPS, then open the site and test it. Never use php artisan serve as the public production server.

Laravel database migrations

Laravel environment settings

## Server practical 3: pull a tested update

Now practise Paul’s update routine: local change → test → push → server pull → deploy → live check.

1. Push your tested commit to GitHub. Record its ID. Back up the server database and uploaded files. Confirm that you can restore the backup.

2. Connect by SSH. Enter the existing project directory. Run these checks one at a time.

```text
cd /path/to/training-site
git status
git branch --show-current
git rev-parse HEAD
```

Replace the path with the real directory. status must show a clean working tree. Confirm the deployment branch, normally main, and record the old commit ID for recovery. If there are local changes, stop and investigate; do not erase them.

3. For this small training site, enter maintenance mode. Then pull only a straightforward update. If any command fails, stop and resolve it before continuing.

```text
php artisan down
git pull --ff-only origin main
composer install --no-dev --optimize-autoloader
```

down temporarily shows maintenance mode. pull downloads the main branch and refuses to invent a merge if histories differ. Composer installs the dependencies for the new code.

4. Build assets if this project requires them. Review new migrations. Apply them only after checking the backup and the intended database. Use the build and migration commands from the previous lesson.

```text
php artisan optimize
php artisan up
```

optimize prepares Laravel’s caches. up ends maintenance mode. If the update uses long-running workers, restart them using the command documented for your Laravel version and host.

5. Open the real HTTPS address in a fresh browser tab. Check the homepage, changed feature, form validation and one fictional test submission. Confirm the deployed commit ID with git rev-parse HEAD.

If deployment fails, visitors may still see maintenance mode. Restore a known-working release and compatible settings, then bring the site up after checks. Do not blindly reverse database migrations. A code rollback alone may not undo a schema change.

OUTPUT  The live test shows your intended change, the commit matches GitHub, and existing features still work. These are guided deployment checks; no deployment to your server was performed for this handout.

## Choose the right home for your website

**Plain HTML, CSS and browser JavaScript** — Can use static hosting such as GitHub Pages.

**PHP or Laravel** — Needs PHP-capable hosting and the database/settings your project uses. GitHub Pages cannot run PHP.

**Django** — Needs Python application hosting, a production application server and the project database. The development runserver command is not production hosting.

**Flutter web** — Build with flutter build web. Publish the generated build/web files to web hosting. A separate API still needs its own server.

A professional improvement is automated deployment after a reviewed change. First understand the manual routine. Later, let CI run tests, build assets and deploy an approved release with rollback support.

Your finish line: you can explain where the files live, how to start the local site, which commit is online, and how to recover a failed update. That is control of your project—not just prompting.

Tool references in these added lessons were checked on 14 October 2026. Screens and account allowances change; follow the linked official guide when your screen differs.

