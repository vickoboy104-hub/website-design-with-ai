<?php
$quantity = 12;
$unitPrice = 4000;
function subtotal(int $quantity, int $price): int {
    return $quantity * $price;
}
$total = subtotal($quantity, $unitPrice);
if ($quantity >= 10) {
    $note = 'Bulk enquiry';
} else {
    $note = 'Small enquiry';
}
?>
<!doctype html>
<html lang="en">
<head><meta charset="UTF-8"><title>Cap quote</title></head>
<body>
  <h1>Practice cap quotation</h1>
  <p>Quantity: <?= $quantity ?></p>
  <p>Total: NGN <?= $total ?></p>
  <p><?= $note ?></p>
</body>
</html>