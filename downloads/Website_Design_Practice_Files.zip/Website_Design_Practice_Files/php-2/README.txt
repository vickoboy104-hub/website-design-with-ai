PHP practical 2: A server calculated quotation page

Calculate a fixed example and use a condition and reusable function.

HOW TO RUN
Open this folder in VS Code. Choose Terminal → New Terminal. Run php -S 127.0.0.1:8000. Keep it running, then open http://127.0.0.1:8000/index.php. Stop the earlier server with Ctrl + C before starting another.

EXPECTED RESULT
Practice cap quotation
Quantity: 12
Total: NGN 48000
Bulk enquiry

WHAT THE CODE DOES
$quantity, $unitPrice and $total: Store two whole-number inputs and the calculated result.
function, int parameters and return: Define a reusable whole-number multiplication and return its result.
*, = and semicolons: Multiply, assign and end statements.
if, >=, else and braces: Choose the note according to the quantity.
<?= ?>: Output controlled numeric values and fixed strings; user-provided strings would need escaping.
HTML structure, title, h1 and p: Create a valid page and display the three results.

TRY IT
Change quantity to 5. Predict 20000 and Small enquiry, then verify.

CHECK
12 produces 48000.
5 selects the small-enquiry branch.