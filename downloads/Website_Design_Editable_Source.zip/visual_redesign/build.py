from pathlib import Path
import json,re,html,textwrap,math
from PIL import Image
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor,white
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import Paragraph
from reportlab.lib.styles import ParagraphStyle
R=Path(__file__).parent;S=json.loads((R/'sections.json').read_text());W,H=390,780;X=22;CW=346
for n,f in [('Text','DejaVuSans.ttf'),('Bold','DejaVuSans-Bold.ttf'),('Code','DejaVuSansMono.ttf')]:pdfmetrics.registerFont(TTFont(n,'/usr/share/fonts/truetype/dejavu/'+f))
pdfmetrics.registerFontFamily('Text',normal='Text',bold='Bold',italic='Text',boldItalic='Bold')
INK='#14243D';MUTED='#53647D';BG='#F0F4FA';PALETTE=['#08776F','#285CCC','#A44B13','#7640BC','#007C9D','#C13D60','#47771B','#215CC5','#743EC2']
E=lambda t:html.escape(t,quote=False)
def para(t,w=CW,size=18,font='Text',color=INK):
 p=Paragraph(t,ParagraphStyle('p',fontName=font,fontSize=size,leading=size*1.34,textColor=HexColor(color),splitLongWords=True,allowWidows=0,allowOrphans=0));_,h=p.wrap(w,10000);return p,h
def rich(b):
 t=E(b.get('text',''))
 for a in b.get('links',[]):
  if a['url'] and a['text']:t=t.replace(E(a['text']),'<a href="'+html.escape(a['url'],quote=True)+'" color="#285CCC">'+E(a['text'])+'</a>')
 return t
# Remove duplicated navigation and repetitive transition instructions; retain substantive teaching.
S[0]['blocks']=[{'type':'p','text':'Keep this guide on your phone. Do the practical work on your computer.'},{'type':'explain','items':[['LOOK','See a diagram or real example.'],['DO','Follow the numbered actions.'],['CHECK','Compare your result, then try one change.']]},{'type':'p','text':'Tap Contents at the bottom of any page. Choose a subject, then a lesson. Back and Next move one page at a time.'},{'type':'p','text':'Code stays at its original size. For copying, open the web reader from the course files page. A PDF cannot offer reliable copy buttons on every phone.'}]
S[1]['blocks']=[{'type':'p','text':'You can start even if you have never used a computer. Begin with one click, one file and one small success.'},{'type':'explain','items':[['Your pace','Try one lesson at a time. Stop when you need a break.'],['Your habit','Read a step, do it, and look at what changed.'],['Your proof','Show the working result before moving on.']]},{'type':'p','text':'Start with Computer lesson 1. You do not need an AI account for the first lessons.'}]
S[4]['blocks']=[{'type':'p','text':'This book has nine subjects. Each subject starts with its own lesson menu.'},{'type':'explain','items':[['DO','A numbered action to carry out now.'],['NOTICE','A small idea that explains what happened.'],['TRY','Change something and observe the result.'],['CHECK','Your finish line before the next lesson.']]},{'type':'p','text':'The coloured strip tells you where you are. The footer buttons are clickable. Code and real outputs have their own clearly labelled panels.'}]
# Build subject groups, with compact visual menus instead of a long front TOC.
groups=[{'title':'Start here','color':'#08776F','secs':[]}];part=0
for s in S:
 m=re.match(r'Part (\d+) (.*)',s['title'])
 if m:part=int(m[1]);groups.append({'title':m[2],'color':PALETTE[part-1],'secs':[],'part':part})
 s['group']=len(groups)-1;s['color']=groups[-1]['color'];groups[-1]['secs'].append(s)
# Short display titles preserve the topic; full names remain in subject menus.
def short(t):
 t=re.sub(r'^(?:Further lesson|Computer lesson|Internet lesson|Setup lesson) \d+ ','',t)
 t=t.replace('Output and code explanation','See the result & understand the code').replace('Expected output and practical checks','See the result & test it')
 return t
# Semantic page elements. None is split across pages except long code, split at original lines.
def prepare(s):
 blocks=[];title=s['title'];mode='LEARN'
 for b in s['blocks']:
  typ=b['type'];t=b.get('text','').strip()
  if typ=='h':
   if t in ['What you should see','What each part does','What you see','What each configuration value does']:continue
   blocks.append({'kind':'heading','text':t});continue
  if typ=='image':
   cap=b['caption'] or '';real='Actual Chromium' in cap or 'Real interface' in cap or 'Real Kilo' in cap
   blocks.append({'kind':'image','path':b['path'],'caption': 'REAL WEBSITE OUTPUT' if 'Actual Chromium' in cap else 'REAL TOOL INTERFACE' if real else 'VISUAL EXPLANATION','real':real});continue
  if typ=='code':
   lines=[]
   for ln in b['text'].split('\n'):lines.extend(textwrap.wrap(ln,width=56,replace_whitespace=False,drop_whitespace=False,break_long_words=True,break_on_hyphens=False) or [' '])
   for i in range(0,len(lines),33):blocks.append({'kind':'code','lines':lines[i:i+33],'label':'TYPE / COPY THIS CODE' if i==0 else 'CODE CONTINUED'})
   continue
  if typ=='explain':
   it=b['items']
   if len(it)==2 and it[0][0] in ['Tag or code','Code','Code and file','Key','Shortcut','Word','Name','Part','Tool or stack','Tool','You use','Subject','Stage','Project']:
    blocks.append({'kind':'meaning','term':it[0][1],'text':it[1][1]})
   else:
    for label,tx in it:
     if tx:blocks.append({'kind':'meaning','term':label,'text':tx})
   continue
  if typ!='p' or not t:continue
  if t.startswith('Now run the page or query') or t.startswith('Save this file. The complete project runs') or t in ['Source: S6.']:continue
  t=t.replace('Click the Downloads link at the top','Open Download your course files from Contents')
  if t.startswith(('Source:','Sources:','References:','Reference:')):blocks.append({'kind':'source','text':t});continue
  kind='note';label='NOTICE';m=re.match(r'^(\d+)\.\s*(.*)',t,re.S)
  if m:kind='step';label=m[1];t=m[2]
  else:
   for prefix,lab in [('READY TO CONTINUE','CHECK'),('IF IT DOES NOT WORK','FIX IT'),('TRY IT','TRY'),('TRY','TRY'),('CHECK','CHECK'),('OUTPUT','RESULT'),('Your turn:','TRY'),('Your task:','DO'),('Try:','TRY'),('Use:','YOU NEED'),('Job:','YOUR GOAL')]:
    if t.startswith(prefix):label=lab;t=t[len(prefix):].strip(' :');break
  b=dict(b,text=t);tx=rich(b)
  # Break very long prose at sentence boundaries, keeping every sentence.
  if len(t)>520 and not b.get('links'):
   sentences=re.split(r'(?<=[.!?])\s+(?=[A-Z])',t);chunks=[];cur=''
   for z in sentences:
    if len(cur+' '+z)>390 and cur:chunks.append(cur);cur=z
    else:cur=(cur+' '+z).strip()
   if cur:chunks.append(cur)
   for z in chunks:blocks.append({'kind':kind,'label':label,'text':E(z)})
  else:blocks.append({'kind':kind,'label':label,'text':tx})
 return blocks
# Mobile-sized vector diagrams replace tiny generic graphics in core concept lessons.
diagrams={
'Internet lesson 1 What the internet actually is':[('YOUR DEVICE','A phone or computer'),('CONNECTION','Wi-Fi, cable or mobile data'),('INTERNET','Many connected networks'),('OTHER COMPUTERS','They send information back')],
'Internet lesson 4 Follow a webpage from request to screen':[('BROWSER','You enter a web address'),('DNS','Finds the server address'),('REQUEST','Browser asks for the page'),('RESPONSE','Server sends files back'),('SCREEN','Browser displays the page')],
'Internet lesson 8 Meet the five subjects we will practise':[('HTML','Content and structure'),('CSS','Colour, spacing and layout'),('JAVASCRIPT','Actions in the browser'),('PHP','Work on the server'),('SQL','Read and change stored data')],
'Paul’s workflow: from an idea to a live website':[('IDEA','Explain the job clearly'),('AI + PROJECT FOLDER','Build, review and correct'),('LOCAL BROWSER','Try the working result'),('GITHUB','Save a tested checkpoint'),('SERVER','Deploy and check the live site')]
}
# Plan every page before drawing, so navigation and local progress are exact.
pages=[]
def addpage(s,items,kind='lesson'):pages.append({'s':s,'items':items,'kind':kind})
def height(b):
 k=b['kind']
 if k=='heading':return para(E(b['text']),CW,20,'Bold')[1]+15
 if k=='source':return para(E(b['text']),CW,11)[1]+12
 if k=='code':return 48+len(b['lines'])*12.5
 if k=='image':
  with Image.open(b['path']) as im:w,h=im.size
  ih=min(350 if b['real'] else 170,(CW-24)*h/w);b['ih']=ih;return ih+54
 if k=='meaning':return 36+para(E(b['term']),CW-32,18,'Bold')[1]+para(E(b['text']),CW-32,18)[1]
 if k=='diagram':return len(b['rows'])*91+18
 return 46+para(b['text'],CW-60 if k=='step' else CW-32,18)[1]
def pack(s,blocks):
 cur=[];used=0;cap=554
 for j,b in enumerate(blocks):
  bh=height(b)
  if bh>cap:raise ValueError(('Too tall',s['title'],b,bh))
  reserve=12+height(blocks[j+1]) if b['kind']=='heading' and j+1<len(blocks) else 0
  if cur and used+bh+reserve>cap:addpage(s,cur);cur=[];used=0
  cur.append(b);used+=bh+12
 if cur:addpage(s,cur)
addpage(None,[],'cover');addpage(None,[],'map')
for gi,g in enumerate(groups):
 # Limit menu to five large touch rows per page.
 for off in range(0,len(g['secs']),5):addpage({'group':gi,'color':g['color'],'title':g['title'],'id':f'group_{gi}'},g['secs'][off:off+5],'menu')
 for s in g['secs']:
  if s['title'].startswith('Part '):
   blocks=prepare(s);blocks=[b for b in blocks if b['kind']!='image'];pack(s,blocks);continue
  blocks=prepare(s)
  if s['title'] in diagrams:
   blocks=[b for b in blocks if b['kind']!='image'];blocks.insert(0,{'kind':'diagram','rows':diagrams[s['title']]})
  pack(s,blocks)
# Define all destinations and per-lesson counts.
first={};local={}
for i,p in enumerate(pages):
 key='cover' if p['kind']=='cover' else 'contents' if p['kind']=='map' else p['s']['id']
 first.setdefault(key,i);local.setdefault(key,[]).append(i);p['key']=key
out=R/'output/Practical_Website_Design_with_AI.pdf';C=canvas.Canvas(str(out),pagesize=(W,H));C.setTitle('Website Design with AI - Visual Mobile Workbook');C.setAuthor('Paul Victor | Beloved Technology')
def rect(x,y,w,h,fill,r=0,stroke=None):
 C.setFillColor(HexColor(fill));C.setStrokeColor(HexColor(stroke or fill));C.roundRect(x,H-y-h,w,h,r,stroke=bool(stroke),fill=1)
def txt(t,x,y,size=12,color=INK,font='Text'):
 C.setFillColor(HexColor(color));C.setFont(font,size);C.drawString(x,H-y-size,t)
def drawp(t,x,y,w,size=18,font='Text',color=INK):
 p,h=para(t,w,size,font,color);p.drawOn(C,x,H-y-h);return h
def button(t,x,y,w,dest,fill='#FFFFFF',color=INK):
 rect(x,y,w,36,fill,10);txt(t,x+12,y+9,12,color,'Bold');C.linkAbsolute(t,dest,(x,H-y-36,x+w,H-y),thickness=0)
def icon(x,y,kind,color):
 # Small precise vector symbols (not screenshots).
 C.setStrokeColor(HexColor(color));C.setLineWidth(2)
 if kind=='code':
  p=C.beginPath();p.moveTo(x+8,H-y);p.lineTo(x,H-y-8);p.lineTo(x+8,H-y-16);C.drawPath(p);p=C.beginPath();p.moveTo(x+18,H-y);p.lineTo(x+26,H-y-8);p.lineTo(x+18,H-y-16);C.drawPath(p);C.line(x+15,H-y,x+11,H-y-16)
 else:C.circle(x+10,H-y-9,8,stroke=1,fill=0)
def header(p,i):
 s=p['s'];color=s['color'];g=groups[s['group']];rect(0,0,W,H,BG);rect(0,0,W,150,color)
 txt('BELOVED TECHNOLOGY',X,18,10,'#FFFFFF','Bold');txt(f'{s["group"]:02d}  /  {g["title"][:34]}',X,38,11,'#FFFFFF')
 label=short(s['title']);sz=23
 while para(E(label),CW,sz,'Bold')[1]>78:sz-=1
 drawp(E(label),X,61,CW,sz,'Bold','#FFFFFF')
 seq=local[p['key']];num=seq.index(i)+1;txt(f'{num} / {len(seq)}',W-63,18,10,'#FFFFFF','Bold')
 for n in range(min(len(seq),20)):
  width=(CW-4*(min(len(seq),20)-1))/min(len(seq),20);rect(X+n*(width+4),144,width,3,'#FFFFFF' if n<num else '#ACBADD',1)
def block(b,y,color):
 k=b['kind'];bh=height(b)
 if k=='heading':drawp(E(b['text']),X,y,CW,20,'Bold',color)
 elif k=='source':drawp(E(b['text']),X,y,CW,11,color=MUTED)
 elif k=='image':
  rect(X,y,CW,bh,'#FFFFFF',14);txt(b['caption'],X+12,y+11,10,color,'Bold')
  with Image.open(b['path']) as im:w,h=im.size
  ih=b['ih'];iw=ih*w/h;C.drawImage(b['path'],X+(CW-iw)/2,H-y-34-ih,width=iw,height=ih,mask='auto')
 elif k=='code':
  rect(X,y,CW,bh,'#E7EEF6',14);rect(X,y,CW,32,'#172B48',12);icon(X+12,y+8,'code','#8ADDCF');txt(b['label'],X+49,y+9,10,'#FFFFFF','Bold');C.setFillColor(HexColor('#17496B'));C.setFont('Code',9.5)
  for j,line in enumerate(b['lines']):C.drawString(X+12,H-y-48-j*12.5,line)
 elif k=='meaning':
  rect(X,y,CW,bh,'#FFFFFF',14);rect(X,y,5,bh,color,2)
  th=drawp(E(b['term']),X+16,y+12,CW-32,18,'Bold',color);drawp(E(b['text']),X+16,y+20+th,CW-32,18)
 elif k=='diagram':
  for j,(a,z) in enumerate(b['rows']):
   yy=y+j*91;rect(X,yy,CW,73,'#FFFFFF',14);rect(X+12,yy+14,33,33,color,10);txt(str(j+1),X+23,yy+19,17,'#FFFFFF','Bold');txt(a,X+57,yy+12,13,color,'Bold');drawp(E(z),X+57,yy+34,CW-70,15)
   if j<len(b['rows'])-1:txt('↓',X+CW/2-6,yy+72,16,color,'Bold')
 else:
  colors={'TRY':('#FFF1CF','#916009'),'CHECK':('#DFF3EB','#176E50'),'FIX IT':('#FBE7EB','#A43251'),'RESULT':('#DFF3EB','#176E50')};fill,cc=colors.get(b['label'],('#FFFFFF',color));rect(X,y,CW,bh,fill,14)
  if k=='step':
   rect(X+12,y+14,28,28,color,9);txt(b['label'],X+20,y+18,14,'#FFFFFF','Bold');drawp(b['text'],X+48,y+14,CW-60,18)
  else:txt(b['label'],X+16,y+12,10,cc,'Bold');drawp(b['text'],X+16,y+31,CW-32,18)
 return bh
for i,p in enumerate(pages):
 C.bookmarkPage('p'+str(i));
 if i==first[p['key']]:C.bookmarkPage(p['key']);C.addOutlineEntry('Contents' if p['key']=='contents' else 'Cover' if p['kind']=='cover' else p['s']['title'],p['key'],0,False)
 kind=p['kind']
 if kind=='cover':
  rect(0,0,W,H,'#102641');rect(250,-60,200,230,'#176F78',60);rect(-80,590,230,250,'#593A9C',60)
  txt('BELOVED TECHNOLOGY',X,32,12,'#8FE1D3','Bold');drawp('Website<br/>Design<br/>with AI',X,91,CW,44,'Bold','#FFFFFF');txt('VISUAL MOBILE WORKBOOK',X,288,12,'#F9D78C','Bold')
  rect(X,337,CW,220,'#FFFFFF',22);rect(X+16,353,CW-32,29,'#E8EEF7',9)
  for j,col in enumerate(['#E87B8D','#E7BD61','#5DC5AE']):C.setFillColor(HexColor(col));C.circle(X+31+j*15,H-367,4,fill=1,stroke=0)
  txt('Your first website',X+30,401,24,INK,'Bold');rect(X+30,446,180,9,'#D4DFEF',4);rect(X+30,464,245,9,'#D4DFEF',4);rect(X+30,495,126,36,'#08776F',9);txt('I made this!',X+42,504,14,'#FFFFFF','Bold')
  txt('A teaching illustration',X+22,565,10,'#B4C8E0');txt('Paul Victor',X,619,21,'#FFFFFF','Bold');txt('Look. Do. Check. Keep going.',X,653,16,'#DAE6F5');button('Start learning  →',X,705,CW,'contents','#8FE1D3')
 elif kind=='map':
  rect(0,0,W,H,BG);rect(0,0,W,133,'#102641');txt('YOUR LEARNING PATH',X,25,11,'#8FE1D3','Bold');drawp('What will you<br/>build today?',X,49,CW,29,'Bold','#FFFFFF')
  for gi,g in enumerate(groups):
   y=151+gi*53;rect(X,y,CW,44,'#FFFFFF',12);rect(X,y,43,44,g['color'],12);txt(str(gi).zfill(2),X+10,y+12,15,'#FFFFFF','Bold');label=g['title'];label=label.replace('HTML gives content a structure','HTML').replace('CSS gives the page its appearance','CSS').replace('JavaScript makes a page respond','JavaScript').replace('PHP works on the server','PHP').replace('SQL works with stored data','SQL').replace('Put the five subjects together','Five complete websites').replace('Build with AI and explore more tools','AI, frameworks & publishing')
   drawp(E(label),X+56,y+10,CW-70,15,'Bold');C.linkAbsolute(label,'group_'+str(gi),(X,H-y-44,W-X,H-y),thickness=0)
  txt('Tap a subject. Then choose a lesson.',X,699,14,MUTED)
 elif kind=='menu':
  header(p,i);y=174
  for s in p['items']:
   sz=17
   while para(E(short(s['title'])),CW-30,sz,'Bold')[1]>50:sz-=.5
   rect(X,y,CW,91,'#FFFFFF',14);txt('OPEN LESSON  →',X+15,y+10,10,s['color'],'Bold');drawp(E(short(s['title'])),X+15,y+31,CW-30,sz,'Bold');C.linkAbsolute(s['title'],s['id'],(X,H-y-91,W-X,H-y),thickness=0);y+=105
 else:
  header(p,i);y=168
  for b in p['items']:y+=block(b,y,p['s']['color'])+12
 if kind!='cover':
  rect(0,735,W,45,'#102641');button('‹ Back',12,740,90,'p'+str(max(0,i-1)),'#243D5B','#FFFFFF');button('Contents',112,740,110,'contents','#243D5B','#FFFFFF');button('Next ›',232,740,90,'p'+str(min(len(pages)-1,i+1)),'#243D5B','#FFFFFF');txt(str(i+1),337,751,11,'#FFFFFF')
 C.showPage()
C.save();(R/'page_manifest.json').write_text(json.dumps([{'page':i+1,'kind':p['kind'],'title':p['s']['title'] if p['s'] else p['kind'],'items':[b.get('kind') for b in p['items']]} for i,p in enumerate(pages)]));print('Built',len(pages),'visual pages')
