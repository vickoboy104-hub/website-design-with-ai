# Beloved Technology mobile handbook

Author: Paul Victor. This is the editable source, not a flattened PDF.

## Rebuild the PDF

Use Python 3 on Linux with DejaVu fonts installed.

```
python -m pip install reportlab Pillow pygments
python app_handout/build_pdf.py
```

Run the command from this archive's root. Output:
`app_handout/output/Practical_Website_Design_with_AI.pdf`.

Edit lesson content in `visual_redesign/sections.json` and page styling in
`app_handout/build_pdf.py`. The latter reuses the curriculum conversion functions
at the beginning of `visual_redesign/build.py`; it has its own page design.
Images are in `visual_redesign/assets`. Existing screenshots show actual code
outputs; do not replace them with imagined results.

## Companion website

`app_handout/site` is a static website. It includes the exact course snippets,
complete practical files, and 16 runnable HTML/CSS/JavaScript examples.
The same files are in the repository's `docs` directory.

To rebuild its data, extract the course practice ZIP to `app_handout/practice`
then run `python app_handout/build_site.py`. Copy the resulting site to `docs`.

## GitHub Pages activation

In the course repository, choose Settings > Pages > Build and deployment >
Source > GitHub Actions. Then choose Actions > Publish learning website >
Run workflow (main). The workflow tests the site and publishes `docs`.
The first activation requires the repository owner's settings access.

PDF links target https://vickoboy104-hub.github.io/website-design-with-ai/ .
They become live once Pages is enabled and deployment succeeds.
PHP and SQL examples are copyable learning files, not backend hosting on Pages.

## Verification

All 96 code samples were checked for preservation. Browser checks passed for
16 live examples, 26 project copy operations and 96 exact text snippets.
PDF navigation is implemented using internal links and bookmarks; external
code links open exact matching samples. Reader copy behaviour can vary for
wrapped PDF lines; online Copy code preserves the original text exactly.
