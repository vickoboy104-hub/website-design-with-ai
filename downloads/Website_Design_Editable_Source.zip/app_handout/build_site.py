from pathlib import Path
import json,re,shutil
R=Path(__file__).parent;D=R/'site';P=R/'practice/Website_Design_Practice_Files';S=json.loads(Path('visual_redesign/sections.json').read_text());D.mkdir(exist_ok=True)
projects=[]
for d in sorted(P.iterdir()):
 if not d.is_dir() or not re.fullmatch(r'(html|css|javascript|php|sql|website)-[1-5]|ai-bakery',d.name):continue
 files=[]
 for f in sorted(d.rglob('*')):
  if f.is_file() and f.suffix in ['.html','.css','.js','.php','.sql','.txt']:
   files.append({'name':str(f.relative_to(d)),'code':f.read_text()})
 live=d.name.startswith(('html-','css-','javascript-')) or d.name=='ai-bakery'
 if live:shutil.copytree(d,D/'examples'/d.name,dirs_exist_ok=True)
 projects.append({'id':d.name,'title':d.name.replace('-',' ').title(),'live':f'examples/{d.name}/index.html' if live else None,'files':files})
snippets=[]
for s in S:
 for j,b in enumerate(s['blocks']):
  if b['type']=='code':snippets.append({'id':s['id']+'-'+str(j),'title':s['title'],'code':b['text']})
(D/'data.js').write_text('window.COURSE='+json.dumps({'projects':projects,'snippets':snippets},ensure_ascii=False)+';')
(D/'.nojekyll').write_text('')
print(len(projects),'projects;',len(snippets),'snippets')
